import UIKit

//adds any two given numbers
func addition(number1: Float, number2: Float) -> (Float) {
    let sum = number1 + number2
    return sum
}

//prints the result of the function
print(addition(number1: 3.123, number2: 2.235))
