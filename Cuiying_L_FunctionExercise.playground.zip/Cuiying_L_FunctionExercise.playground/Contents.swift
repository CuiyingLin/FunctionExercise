import UIKit

func addition(number1: Float, number2: Float) -> (Float) {
    let sum = number1 + number2
    return sum
}

print(addition(number1: 3.123, number2: 2.235))
